#ifdef __cplusplus
#ifndef VS_H
#define VS_H

#include <vector>
#include <string>

void get_vector_stats(std::vector<std::string> vect);
void get_array_stats(std::string arr[], int arr_length);
void display_stats();

#endif
#endif